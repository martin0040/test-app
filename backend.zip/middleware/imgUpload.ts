import multer from 'multer';
import path from 'path';

const storage = multer.diskStorage({
    destination: (req, file, cb) => cb(null, 'uploads/'), // Specify the upload directory
    filename: (req, file, cb) => cb(null, Date.now().toString()) // Rename the file
});

// Initialize Multer with the storage configuration
const upload = multer({
    storage: storage,
    limits: { fileSize: 10 * 1024 * 1024 }, // Limit file size to 10MB
    fileFilter: function (req, file: any, cb) {
        // Validate file type (e.g., only allow images)
        const fileTypes = /jpg|jpeg|jpg|png|gif/;
        const extname = fileTypes.test(file.mimetype) && fileTypes.test(file.originalname.split('.').pop().toLowerCase());
        if (extname) {
            return cb(null, true);
        } else {
            cb(new Error('Only images are allowed!'));
        }
    }
}).single('image'); // Specify the field name for the file input

export default upload;



