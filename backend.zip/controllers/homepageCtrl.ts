import { Request, Response, NextFunction } from "express";
import { Session } from 'express-session'
import Homepage from '../models/Homepage';
import { homepageValidator } from '../validator/homepage';
import upload from '../middleware/imgUpload';

interface CustomRequest extends Request {
  session: Session & { user?: any }; // Adjust based on your actual session structure
}

export const getData = async (req: CustomRequest, res: Response) => {
  try {
    const { user } = req?.session;
    if (!user) res.send([]);
    else {
      const homepageData = await Homepage.find({ user: user._id });
      res.send(homepageData);
    }
  } catch (error) {
    console.log("Get Homepage Data Error:", error);
    res.status(500).json({ msg: 'Interval server error.' });
  }
}
export const addData = async (req: CustomRequest, res: Response) => {
  interface dataTypes {
    title: string,
    url: string
    description: string
  }
  try {
    upload(req, res, async (err: any) => {
      if (err) return res.status(400).json({ messsage: 'Upload Error' })
      const user = req.session.user;
      if (!user) return res.status(400).json({ message: 'Must Sign In' })
      const data: dataTypes = JSON.parse(req.body.data);
      const { isValid, msg } = homepageValidator(data);
      if (!isValid) return res.status(400).json({ message: msg });
      const urlExist = await Homepage.findOne({ url: data.url });
      if (urlExist) return res.status(400).json({ message: 'That URL Exist' });
      await Homepage.create({
        title: data.title,
        url: data.url,
        description: data.url,
        user: user._id,
        image: req?.file?.filename
      })
      const homepages = await Homepage.find({ user: user._id });
      res.send({ status: 'created', msg: 'User created successfully.', homepages });
    });
  } catch (error) {
    console.log("Register Error:", error);
    res.status(500).json({ msg: 'Interval server error.' });
  }
}