import { Request, Response } from "express";
import { Session } from 'express-session';
import bcrypt from 'bcryptjs';
import User from '../models/User';
import { isEmpty, isValidEmail } from '../validator/validator'
import { registerValidator } from '../validator/auth'

interface CustomRequest extends Request {
    session: Session & { user?: any }; // Adjust based on your actual session structure
}
export const register = async (req: CustomRequest, res: Response) => {
    try {
        const { email, password } = req.body;
        const { isValid, msg } = registerValidator(req.body);

        if (!isValid) res.status(500).json({ message: msg })
        else {
            const userExist = await User.findOne({ email });
            if (userExist) res.status(400).json({ message: 'User Exist' })
            else {
                const hashedPassword = await bcrypt.hash(password, 10);
                const regData = await User.create({
                    ...req.body,
                    password: hashedPassword
                })
                req.session.user = { _id: regData._id, email: regData.email };
                res.send({ status: 'created', msg: 'User created successfully.' });
            }
        }
    } catch (error) {
        console.log("Register Error:", error);
        res.status(500).json({ msg: 'Interval server error.' });
    }
}
export const login = async (req: CustomRequest, res: Response) => {
    const { email, password } = req.body;

    if (!isValidEmail(email)) res.status(500).json({ status: 'error', message: 'Invalid email' });
    else {
        if (isEmpty(password)) res.status(500).json({ status: 'error', message: 'Password is required' });
        else {
            const user = await User.findOne({ email });
            if (!user) res.status(400).send({ message: 'User Not Found.' });
            else {
                const isMatch = await bcrypt.compare(password, user.password);
                if (!isMatch) res.status(400).send({ message: 'Wrong Password.' });
                else {
                    const session = req.session.user = { _id: user._id, email: user.email };
                    res.status(200).send({ msg: 'Login Success', session });
                }
            }
        }
    }
}
export const logOut = async (req: CustomRequest, res: Response) => {
    req.session.destroy((err: any) => {
        if (err) return res.status(500).send('Could not log out.');
        res.send('Logged out successfully!');
    });
}
export const getUserInfo = async (req: CustomRequest, res: Response) => {
    const session = req.session;
    if (!session.user) res.status(404).json('NOT-USER');
    else res.send({
        isAuthenticated: true,
        userInfo: session.user
    })
}