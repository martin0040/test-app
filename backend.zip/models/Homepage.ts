import mongoose, { Document, Schema } from 'mongoose';

export interface IHomepage extends Document {
  user: mongoose.Types.ObjectId
  title: string
  url: string
  description: string
  image: string
}

const homepageSchema: Schema = new Schema({
  user: { type: mongoose.Types.ObjectId },
  title: { type: String },
  url: { type: String },
  description: { type: String },
  image: { type: String, default: 'default' }
});

const HomepageModel = mongoose.model<IHomepage>('homepage', homepageSchema);

export default HomepageModel;