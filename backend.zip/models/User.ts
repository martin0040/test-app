import mongoose, { Document, Schema } from 'mongoose';

export interface IUser extends Document {
  firstName: string
  lastName: string
  avatar: string
  email: string
  password: string
}

const userSchema: Schema = new Schema({
  firstName: { type: String },
  lastName: { type: String },
  avatar: { type: String, default: 'defaultAvatar' },
  email: { type: String, required: true },
  password: { type: String, required: true },
});

const UserModel = mongoose.model<IUser>('user', userSchema);

export default UserModel;