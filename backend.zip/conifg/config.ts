export const secretKey = 'my_own_secretKey'
export const mongoURI = 'mongodb://127.0.0.1:27017/app'