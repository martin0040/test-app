import express from 'express';
import { login, register, getUserInfo, logOut } from '../controllers/authCtrl'

const router = express.Router()

router.post('/register', register);
router.post('/login', login);
router.post('/logout', logOut);
router.post('/get-user-info', getUserInfo);

export default router;

