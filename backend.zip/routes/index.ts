import { Request, Response } from "express"
import authRouter from './authRouter'
import homepageRouter from './homepageRouter'
import path from "path"
const Router = (app: any) => {
    app.get('/uploads/:id', (req: Request, res: Response) => {
        const id = req.params.id;
        res.sendFile(path.resolve(__dirname, '../uploads', id));
    });
    app.use('/api/auth', authRouter);
    app.use('/api/homepage', homepageRouter);
}

export default Router;