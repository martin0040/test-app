import express from 'express';
import { addData, getData } from "../controllers/homepageCtrl";

const router = express.Router();

router.post('/get-data', getData);
router.post('/add-data', addData);

export default router;

